<!-- Navigation -->
<nav>
    <a href="{{ route('home') }}">Inicio</a>
    &nbsp;&nbsp;&nbsp;
    <a href="{{ route('cuenta_list') }}">Cuentas</a>
    &nbsp;
    <a href="{{ route('cliente_list') }}">Clientes</a>
</nav>
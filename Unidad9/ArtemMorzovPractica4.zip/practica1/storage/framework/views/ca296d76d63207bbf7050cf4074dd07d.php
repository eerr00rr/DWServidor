<?php $__env->startSection('title', 'Nueva Cliente'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('stylesheets'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Nueva Cliente</h1>
<a href="<?php echo e(route('cliente_list')); ?>">&laquo; Volver</a>
<div style="color: red;">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<div style="margin-top: 20px">
    <form method="POST" action="<?php echo e(route('cliente_new')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label for="dni">DNI</label>
            <input type="text" name="dni" />
        </div>
        <div>
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" />
        </div>
        <div>
            <label for="apellidos">Apellidos</label>
            <input type="text" name="apellidos" />
        </div>
        <div>
            <label for="fechaN">Fecha Nacimiento</label>
            <input type="date" name="fechaN" value="<?php echo e(date_create()->format('Y-m-d')); ?>" />
        </div>
        <div>
            <label for="imagen">Imagen</label>
            <input type="file" name="imagen" />
        </div>
        <button type="submit">Crear cliente</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DWServidor/Unidad9/practica1/resources/views/cliente/new.blade.php ENDPATH**/ ?>
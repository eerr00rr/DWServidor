<?php $__env->startSection('title', 'Listado de cuentas'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('stylesheets'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Listado de cuentas</h1>
<a href="<?php echo e(route('cuenta_new')); ?>">+ Nueva cuenta</a>
<?php if(session('status')): ?>
<div>
    <strong>Success!</strong> <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<table style="margin-top: 20px;margin-bottom: 10px;">
    <thead>
        <tr>
            <th>Código</th>
            <th>Saldo</th>
            <th>Cliente</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cuenta->codigo); ?></td>
            <td><?php echo e($cuenta->saldo); ?></td>
            <?php if(isset($cuenta->cliente)): ?>
            <td><?php echo e($cuenta->cliente->getNombreApellidos()); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <td>
                <a href="<?php echo e(route('cuenta_delete', ['id' => $cuenta->id])); ?>">Eliminar</a>
                <br>
                <a href="<?php echo e(route('cuenta_edit', ['id' => $cuenta->id])); ?>">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DWServidor/Unidad9/practica1/resources/views/cuenta/list.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Nueva Cuenta'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('stylesheets'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Edit Cuenta</h1>
<a href="<?php echo e(route('cuenta_list')); ?>">&laquo; Volver</a>
<div style="margin-top: 20px">
    <form method="POST" action="<?php echo e(route('cuenta_edit', ['id' => $cuenta->id])); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="codigo">Código</label>
            <input type="text" name="codigo" value="<?php echo e($cuenta->codigo); ?>" />
        </div>
        <div>
            <label for="saldo">Saldo</label>
            <input type="number" name="saldo" value="<?php echo e($cuenta->saldo); ?>" />
        </div>
        <div>
            <label for="cliente_id">Cliente</label>
            <select name="cliente_id">
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cliente->id); ?>" <?php if($cliente->id==$cuenta->id): echo 'selected'; endif; ?>>
                    <?php echo e($cliente->nombre); ?><?php echo e($cliente->apellidos); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit">Editar Cuenta</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/DWServidor/Unidad9/practica1/resources/views/cuenta/edit.blade.php ENDPATH**/ ?>
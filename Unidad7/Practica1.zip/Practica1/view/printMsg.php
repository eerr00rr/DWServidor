<?php
	function printMsg($msg) {
		echo "<br/>".$msg;

	}
?>

<?php
	function linkInicio() {
		echo '<br/> <a href="../index.php">Volver</a>';

	}
?>

<?php
	$GLOBALS['server'] = "localhost";
	$GLOBALS['USER']= "root";
	$GLOBALS['PASS']= "";
	$GLOBALS['bd'] = "bank";
?>
